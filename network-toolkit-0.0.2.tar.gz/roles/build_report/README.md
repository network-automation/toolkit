# network.toolkit.build_report

To use this multi-platform network automation build_report role:

## Task example:

```
- name: build a report
  include_role:
    name: build_report
```
