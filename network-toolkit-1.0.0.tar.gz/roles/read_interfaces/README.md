# network.toolkit.read_interfaces

this role will be replaced in the future
