# network.toolkit.facts

To use this multi-platform network automation facts role:

## Task example:

```
- name: load user role
  vars:
    network_resource: vlans
  include_role:
    name: facts
```
